The goal of the game is to avoid the enemy agent for as long as possible. 
Different dificulties will result in the player moving slower and the agent moving faster. 
When the player is green, the player is undetected, when blue they are near to the enemy agent but not detected. 
When the player turns pink, they are detected and are being chased and when red, the player has taken damage. 
Once the player has taken damage, the enemy agent will enter a cooldown mode for ten seconds where it will actively try to avoid the area where it last dealt damage. 
After those ten seconds, the enemy will begin patrolling or chasing if the player is close enough. 
Upon death, which takes 4 hits, the player will activate the death animation which is the shatter mesh and the game will restart. 